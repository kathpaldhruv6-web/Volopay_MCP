import express, { type Request, type Response, type NextFunction } from "express";
import { randomBytes, randomUUID, timingSafeEqual, createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import { config } from "./config.js";
import { openDatabase, ALL_SCOPES, ROLE_SCOPES, membershipRole, type Scope } from "./database/db.js";
import { browserSessionMiddleware, createBrowserSession, clearSessionCookie, requireBrowserSession, requireCsrf, verifyPassword, sha256 } from "./auth/browser-session.js";
import type Database from "better-sqlite3";

const db = openDatabase();
const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "256kb" }));
app.use(browserSessionMiddleware(db));
const issuer = config.issuerUrl.origin;
const resource = new URL("/mcp", config.issuerUrl).href;
const now = () => Math.floor(Date.now() / 1000);
const token = () => randomBytes(32).toString("base64url");
const scopesJson = (items: string[]) => JSON.stringify([...new Set(items)]);
const parseScopes = (value: string): string[] => JSON.parse(value) as string[];
const safeEqual = (a: string, b: string) => { const aa=Buffer.from(a); const bb=Buffer.from(b); return aa.length===bb.length && timingSafeEqual(aa,bb); };

function apiError(res: Response, status: number, message: string) { res.status(status).json({ error: message }); }
function userWorkspaces(userId: string) {
  return db.prepare(`SELECT w.id,w.name,w.currency,m.role FROM workspace_members m JOIN workspaces w ON w.id=m.workspace_id WHERE m.user_id=? AND m.active=1 ORDER BY w.name`).all(userId) as Array<{id:string;name:string;currency:string;role:keyof typeof ROLE_SCOPES}>;
}
function csrfSession(req: Request, res: Response) {
  let session = req.browserSession;
  if (!session) session = createBrowserSession(db, res, null);
  return session;
}

// OAuth discovery: RFC 9728 protected-resource metadata and RFC 8414 authorization-server metadata.
app.get("/.well-known/oauth-protected-resource", (_req,res) => res.json({ resource, authorization_servers:[issuer], bearer_methods_supported:["header"], scopes_supported:ALL_SCOPES }));
app.get("/.well-known/oauth-protected-resource/mcp", (_req,res) => res.json({ resource, authorization_servers:[issuer], bearer_methods_supported:["header"], scopes_supported:ALL_SCOPES }));
app.get("/.well-known/oauth-authorization-server", (_req,res) => res.json({
  issuer, authorization_endpoint:`${issuer}/authorize`, token_endpoint:`${issuer}/token`, registration_endpoint:`${issuer}/register`, revocation_endpoint:`${issuer}/revoke`,
  response_types_supported:["code"], response_modes_supported:["query"], grant_types_supported:["authorization_code","refresh_token"],
  token_endpoint_auth_methods_supported:["none"], code_challenge_methods_supported:["S256"], scopes_supported:ALL_SCOPES,
}));
app.post("/register", (req,res) => {
  const body=req.body ?? {}; const redirects=body.redirect_uris;
  if (!Array.isArray(redirects) || !redirects.length || redirects.some((value: unknown)=>typeof value!=="string" || !safeRedirect(value))) return apiError(res,400,"redirect_uris must contain valid HTTPS or loopback HTTP URLs.");
  if (body.token_endpoint_auth_method && body.token_endpoint_auth_method!=="none") return apiError(res,400,"Only public clients are supported.");
  const clientId=randomUUID(); const created=now();
  const client={client_id:clientId,client_id_issued_at:created,token_endpoint_auth_method:"none",grant_types:["authorization_code","refresh_token"],response_types:["code"],redirect_uris:redirects,client_name:typeof body.client_name==="string"?body.client_name:"MCP client"};
  db.prepare("INSERT INTO oauth_clients(client_id,client_json) VALUES(?,?)").run(clientId,JSON.stringify(client));
  res.status(201).json({...client,redirect_uris:redirects});
});
function safeRedirect(uri:string) { try { const u=new URL(uri); return !u.hash && !u.username && !u.password && (u.protocol==="https:" || (u.protocol==="http:" && ["localhost","127.0.0.1","[::1]"].includes(u.hostname))); } catch { return false; } }
app.get("/authorize", (req,res) => {
  const {client_id,redirect_uri,response_type,code_challenge,code_challenge_method,state,scope,resource: requestedResource}=req.query;
  const clientRow=db.prepare("SELECT client_json AS clientJson FROM oauth_clients WHERE client_id=?").get(client_id) as {clientJson:string}|undefined;
  if (!clientRow || response_type!=="code" || typeof redirect_uri!=="string" || typeof code_challenge!=="string" || !/^[A-Za-z0-9_-]{43}$/.test(code_challenge) || code_challenge_method!=="S256" || requestedResource!==resource) return apiError(res,400,"Invalid OAuth authorization request.");
  const client=JSON.parse(clientRow.clientJson) as {redirect_uris:string[]};
  if (!client.redirect_uris.includes(redirect_uri)) return apiError(res,400,"Redirect URI is not registered for this client.");
  const requested=typeof scope==="string"?scope.split(/\s+/).filter(Boolean):[];
  if (!requested.length || requested.some(item=>!ALL_SCOPES.includes(item as Scope))) return apiError(res,400,"Requested scope is not supported.");
  const requestId=token();
  db.prepare(`INSERT INTO pending_authorizations(request_hash,client_id,redirect_uri,state,code_challenge,requested_scopes,resource,expires_at) VALUES(?,?,?,?,?,?,?,?)`).run(sha256(requestId),client_id,redirect_uri,typeof state==="string"?state:null,code_challenge,scopesJson(requested),resource,now()+600);
  res.redirect(302,`${config.webOrigin}/?request=${encodeURIComponent(requestId)}`);
});
app.post("/token", (req,res) => {
  const body=req.body ?? {}; const grant=body.grant_type;
  if (body.resource!==resource) return apiError(res,400,"The token request must be bound to this MCP resource.");
  if (body.client_id && typeof body.client_id!=="string") return apiError(res,400,"Invalid client_id.");
  const clientId=body.client_id as string|undefined;
  const clientRow=clientId?db.prepare("SELECT client_id FROM oauth_clients WHERE client_id=?").get(clientId):undefined;
  if (!clientRow) return apiError(res,401,"Unknown public client.");
  if (grant==="authorization_code") {
    const code=String(body.code??""); const redirectUri=String(body.redirect_uri??""); const verifier=String(body.code_verifier??"");
    if (verifier.length<43 || verifier.length>128 || !/^[A-Za-z0-9._~-]+$/.test(verifier)) return apiError(res,400,"A valid PKCE code_verifier is required.");
    const row=db.prepare(`SELECT code_hash AS codeHash,client_id AS clientId,user_id AS userId,workspace_id AS workspaceId,redirect_uri AS redirectUri,code_challenge AS codeChallenge,scopes,resource,expires_at AS expiresAt,consumed_at AS consumedAt FROM authorization_codes WHERE code_hash=?`).get(sha256(code)) as any;
    const challenge=createHash("sha256").update(verifier).digest("base64url");
    if (!row || row.clientId!==clientId || row.redirectUri!==redirectUri || row.resource!==resource || row.expiresAt<=now() || row.consumedAt!==null || !safeEqual(row.codeChallenge,challenge)) return apiError(res,400,"Authorization code is invalid, expired, reused, or failed PKCE verification.");
    const role=membershipRole(db,row.userId,row.workspaceId); const scopes=parseScopes(row.scopes);
    if (!role || scopes.some(s=>!ROLE_SCOPES[role].includes(s as Scope))) return apiError(res,400,"Workspace permissions have changed. Authorize again.");
    const consume=db.prepare("UPDATE authorization_codes SET consumed_at=? WHERE code_hash=? AND consumed_at IS NULL").run(now(),row.codeHash);
    if (consume.changes!==1) return apiError(res,400,"Authorization code has already been used.");
    return res.json(issueTokens(db,row));
  }
  if (grant==="refresh_token") {
    const refresh=String(body.refresh_token??""); const hash=sha256(refresh);
    const row=db.prepare(`SELECT token_hash AS tokenHash,family_id AS familyId,client_id AS clientId,user_id AS userId,workspace_id AS workspaceId,scopes,resource,expires_at AS expiresAt,consumed_at AS consumedAt,revoked_at AS revokedAt FROM refresh_tokens WHERE token_hash=?`).get(hash) as any;
    if (!row || row.clientId!==clientId || row.resource!==resource) return apiError(res,400,"Refresh token is invalid.");
    if (row.consumedAt!==null) { revokeFamily(db,row.familyId); return apiError(res,400,"Refresh-token reuse detected. The token family has been revoked; authorize again."); }
    if (row.revokedAt!==null || row.expiresAt<=now()) return apiError(res,400,"Refresh token is expired or revoked.");
    const scopes: string[] = typeof body.scope==="string"?body.scope.split(/\s+/).filter(Boolean):parseScopes(row.scopes);
    const previous=parseScopes(row.scopes); const role=membershipRole(db,row.userId,row.workspaceId);
    if (scopes.some(s=>!previous.includes(s) || !ALL_SCOPES.includes(s as Scope))) return apiError(res,400,"Refresh cannot increase permissions.");
    if (!role || scopes.some(s=>!ROLE_SCOPES[role].includes(s as Scope))) { revokeFamily(db,row.familyId); return apiError(res,400,"Workspace access has changed. Authorize again."); }
    const consume=db.prepare("UPDATE refresh_tokens SET consumed_at=? WHERE token_hash=? AND consumed_at IS NULL AND revoked_at IS NULL").run(now(),hash);
    if (consume.changes!==1) { revokeFamily(db,row.familyId); return apiError(res,400,"Refresh-token reuse detected. Authorize again."); }
    return res.json(issueTokens(db,{...row,scopes:scopesJson(scopes)},row.familyId));
  }
  return apiError(res,400,"Unsupported grant_type.");
});
function issueTokens(database:Database.Database,row:any,familyId=randomUUID()) {
  const access=token(), refresh=token(); const timestamp=now();
  database.prepare("INSERT INTO access_tokens(token_hash,family_id,client_id,user_id,workspace_id,scopes,resource,expires_at) VALUES(?,?,?,?,?,?,?,?)").run(sha256(access),familyId,row.clientId,row.userId,row.workspaceId,row.scopes,row.resource,timestamp+900);
  database.prepare("INSERT INTO refresh_tokens(token_hash,family_id,client_id,user_id,workspace_id,scopes,resource,expires_at) VALUES(?,?,?,?,?,?,?,?)").run(sha256(refresh),familyId,row.clientId,row.userId,row.workspaceId,row.scopes,row.resource,timestamp+2592000);
  return {access_token:access,token_type:"Bearer",expires_in:900,refresh_token:refresh,scope:parseScopes(row.scopes).join(" ")};
}
function revokeFamily(database:Database.Database,familyId:string) { const t=now(); database.prepare("UPDATE refresh_tokens SET revoked_at=COALESCE(revoked_at,?) WHERE family_id=?").run(t,familyId); database.prepare("UPDATE access_tokens SET revoked_at=COALESCE(revoked_at,?) WHERE family_id=?").run(t,familyId); }

app.post("/revoke", (req,res) => {
  const clientId=String(req.body?.client_id??""); const raw=String(req.body?.token??"");
  if(!db.prepare("SELECT client_id FROM oauth_clients WHERE client_id=?").get(clientId) || !raw) return res.status(200).end();
  const hash=sha256(raw); const refresh=db.prepare("SELECT family_id AS familyId,client_id AS clientId FROM refresh_tokens WHERE token_hash=?").get(hash) as {familyId:string;clientId:string}|undefined;
  if(refresh?.clientId===clientId) revokeFamily(db,refresh.familyId);
  db.prepare("UPDATE access_tokens SET revoked_at=COALESCE(revoked_at,?) WHERE token_hash=? AND client_id=?").run(now(),hash,clientId);
  db.prepare("UPDATE refresh_tokens SET revoked_at=COALESCE(revoked_at,?) WHERE token_hash=? AND client_id=?").run(now(),hash,clientId);
  return res.status(200).end();
});

// Browser session and demo sign-in API.
app.get("/api/session", (req,res) => { const session=csrfSession(req,res); const userId=req.browserSession?.userId??null; const user=userId?db.prepare("SELECT id,email,display_name AS displayName FROM users WHERE id=?").get(userId):null; res.json({csrfToken:session.csrfToken,user,workspaces:userId?userWorkspaces(userId):[]}); });
app.post("/api/demo-login", (req,res) => {
  // Development-only shortcut: still requires the exact configured browser origin.
  if (!config.demoMode || req.get("origin") !== config.webOrigin) {
    return apiError(res, 403, "Demo sign-in is disabled or the browser origin is not trusted.");
  }
  const user = db.prepare("SELECT id,email,display_name AS displayName FROM users WHERE email=?").get("alex@example.test") as {id:string;email:string;displayName:string}|undefined;
  if (!user) return apiError(res, 500, "Demo user is missing. Run npm run db:init.");
  if (req.rawSessionId) db.prepare("DELETE FROM browser_sessions WHERE session_hash=?").run(sha256(req.rawSessionId));
  const session = createBrowserSession(db, res, user.id);
  res.json({csrfToken:session.csrfToken,user,workspaces:userWorkspaces(user.id),demoMode:true});
});
app.post("/api/login", (req,res) => {
  if (!requireCsrf(req,res)) return;
  const email=String(req.body?.email??"").trim().toLowerCase(); const password=String(req.body?.password??"");
  const user=db.prepare("SELECT id,email,display_name AS displayName,password_hash AS passwordHash FROM users WHERE email=?").get(email) as any;
  if (!user || !verifyPassword(password,user.passwordHash)) return apiError(res,401,"Email or password is incorrect.");
  if (req.rawSessionId) db.prepare("DELETE FROM browser_sessions WHERE session_hash=?").run(sha256(req.rawSessionId));
  const session=createBrowserSession(db,res,user.id); res.json({csrfToken:session.csrfToken,user:{id:user.id,email:user.email,displayName:user.displayName},workspaces:userWorkspaces(user.id)});
});
app.post("/api/logout", (req,res) => { if (!requireCsrf(req,res)) return; if(req.rawSessionId) db.prepare("DELETE FROM browser_sessions WHERE session_hash=?").run(sha256(req.rawSessionId)); clearSessionCookie(res); res.json({ok:true}); });
app.get("/api/authorization/:requestId", (req,res) => {
  const session=requireBrowserSession(req,res); if(!session?.userId) return;
  const pending=db.prepare(`SELECT p.client_id AS clientId,c.client_json AS clientJson,p.requested_scopes AS requestedScopes,p.expires_at AS expiresAt FROM pending_authorizations p JOIN oauth_clients c ON c.client_id=p.client_id WHERE p.request_hash=? AND p.expires_at>?`).get(sha256(req.params.requestId),now()) as any;
  if(!pending) return apiError(res,404,"Authorization request expired. Reconnect from Claude.");
  res.json({client:JSON.parse(pending.clientJson),requestedScopes:parseScopes(pending.requestedScopes),workspaces:userWorkspaces(session.userId),expiresAt:pending.expiresAt});
});
app.post("/api/authorize/:requestId", (req,res) => {
  const session=requireBrowserSession(req,res); if(!session?.userId || !requireCsrf(req,res)) return;
  const pending=db.prepare("SELECT * FROM pending_authorizations WHERE request_hash=? AND expires_at>?").get(sha256(req.params.requestId),now()) as any;
  if(!pending) return apiError(res,404,"Authorization request expired. Reconnect from Claude.");
  if(req.body?.decision==="deny") {
    db.prepare("DELETE FROM pending_authorizations WHERE request_hash=?").run(sha256(req.params.requestId));
    return res.json({redirectUrl:appendQuery(pending.redirect_uri,{error:"access_denied",state:pending.state??undefined})});
  }
  const workspaceId=String(req.body?.workspaceId??""); const role=membershipRole(db,session.userId,workspaceId);
  if(!role) return apiError(res,403,"You do not belong to this workspace.");
  const requested=parseScopes(pending.requested_scopes); const selected=Array.isArray(req.body?.scopes)?req.body.scopes.filter((s:unknown):s is string=>typeof s==="string"):[];
  if(!selected.length || selected.some((s: string)=>!requested.includes(s) || !ROLE_SCOPES[role].includes(s as Scope))) return apiError(res,400,"Selected permissions are not available for this workspace.");
  const code=token(); db.prepare("INSERT INTO authorization_codes(code_hash,client_id,user_id,workspace_id,redirect_uri,code_challenge,scopes,resource,expires_at) VALUES(?,?,?,?,?,?,?,?,?)").run(sha256(code),pending.client_id,session.userId,workspaceId,pending.redirect_uri,pending.code_challenge,scopesJson(selected),pending.resource,now()+60);
  db.prepare("DELETE FROM pending_authorizations WHERE request_hash=?").run(sha256(req.params.requestId));
  res.json({redirectUrl:appendQuery(pending.redirect_uri,{code,state:pending.state??undefined})});
});
function appendQuery(uri:string,values:Record<string,string|undefined>) { const u=new URL(uri); for(const [k,v] of Object.entries(values)) if(v!==undefined)u.searchParams.set(k,v); return u.href; }

function requireScope(auth:any,scope:Scope) { if(!auth.scopes.includes(scope)) throw new Error(`Missing required scope: ${scope}`); }
async function createMcpServer(auth:any) {
  const server=new McpServer({name:"volopay-standalone-demo",version:"1.0.0"},{capabilities:{tools:{}}});
  const workspaceId=String(auth.extra.workspaceId); const userId=String(auth.extra.userId); const requestId=randomUUID();
  const audit=(tool:string,outcome:"success"|"denied"|"error")=>db.prepare("INSERT INTO audit_logs(user_id,workspace_id,tool_name,outcome,request_id) VALUES(?,?,?,?,?)").run(userId,workspaceId,tool,outcome,requestId);
  const tool=(name:string,scope:Scope,description:string,schema:any,handler:(args:any)=>unknown)=>server.registerTool(name,{description,inputSchema:schema},async(args:any)=>{
    try { requireScope(auth,scope); const result=handler(args); audit(name,"success"); return {content:[{type:"text" as const,text:JSON.stringify(result,null,2)}]}; }
    catch(error) { audit(name,"denied"); return {isError:true,content:[{type:"text" as const,text:error instanceof Error?error.message:"Tool request failed."}]}; }
  });
  tool("get_workspace","workspace:read","Get the authorized workspace profile.",{},()=>db.prepare("SELECT id,name,currency FROM workspaces WHERE id=?").get(workspaceId));
  tool("list_transactions","transactions:read","List transactions in the authorized workspace. Amounts are returned in major currency units.",{limit:z.number().int().min(1).max(100).optional(),status:z.enum(["pending","posted","declined","reversed"]).optional()},(args)=>{
    const limit=args.limit??25; return db.prepare(`SELECT id,merchant,ROUND(amount_minor/100.0,2) AS amount,currency,category,status,occurred_at AS occurredAt FROM transactions WHERE workspace_id=? AND (? IS NULL OR status=?) ORDER BY occurred_at DESC LIMIT ?`).all(workspaceId,args.status??null,args.status??null,limit);
  });
  tool("get_transaction","transactions:read","Get one transaction by ID, restricted to the authorized workspace.",{transactionId:z.string().min(1)},(args)=>db.prepare("SELECT id,merchant,ROUND(amount_minor/100.0,2) AS amount,currency,category,status,occurred_at AS occurredAt FROM transactions WHERE id=? AND workspace_id=?").get(args.transactionId,workspaceId)??{error:"Transaction not found in this workspace."});
  tool("list_cards","cards:read","List cards in the authorized workspace. Only the last four digits are exposed.",{},()=>db.prepare("SELECT id,holder_name AS holderName,'•••• '||last_four AS maskedNumber,card_type AS cardType,status,ROUND(monthly_limit_minor/100.0,2) AS monthlyLimit,currency FROM cards WHERE workspace_id=? ORDER BY holder_name").all(workspaceId));
  tool("list_expenses","expenses:read","List expense submissions in the authorized workspace.",{status:z.enum(["pending","approved","rejected"]).optional(),limit:z.number().int().min(1).max(100).optional()},(args)=>db.prepare("SELECT id,submitter_name AS submitter,merchant,ROUND(amount_minor/100.0,2) AS amount,currency,category,approval_status AS status,submitted_at AS submittedAt FROM expenses WHERE workspace_id=? AND (? IS NULL OR approval_status=?) ORDER BY submitted_at DESC LIMIT ?").all(workspaceId,args.status??null,args.status??null,args.limit??25));
  tool("get_spending_summary","reports:read","Summarize posted and pending transaction spend for the authorized workspace.",{},()=>db.prepare("SELECT currency,status,COUNT(*) AS transactionCount,ROUND(SUM(amount_minor)/100.0,2) AS totalAmount FROM transactions WHERE workspace_id=? GROUP BY currency,status ORDER BY currency,status").all(workspaceId));
  return server;
}
async function authenticateMcp(req:Request,res:Response,next:NextFunction) {
  const header=req.get("authorization")??""; const match=/^Bearer\s+(.+)$/i.exec(header);
  if(!match) { res.setHeader("WWW-Authenticate",`Bearer resource_metadata="${issuer}/.well-known/oauth-protected-resource/mcp"`); return apiError(res,401,"A valid bearer access token is required."); }
  const row=db.prepare(`SELECT token_hash AS tokenHash,client_id AS clientId,user_id AS userId,workspace_id AS workspaceId,scopes,resource,expires_at AS expiresAt,revoked_at AS revokedAt FROM access_tokens WHERE token_hash=?`).get(sha256(match[1])) as any;
  if(!row || row.revokedAt!==null || row.expiresAt<=now() || row.resource!==resource) return apiError(res,401,"Access token is invalid, expired, or revoked.");
  const role=membershipRole(db,row.userId,row.workspaceId); const scopes=parseScopes(row.scopes);
  if(!role || scopes.some(s=>!ROLE_SCOPES[role].includes(s as Scope))) return apiError(res,403,"Workspace permissions have changed.");
  (req as any).mcpAuth={token:match[1],clientId:row.clientId,userId:row.userId,workspaceId:row.workspaceId,role,scopes,extra:{userId:row.userId,workspaceId:row.workspaceId,role}}; next();
}
app.post("/mcp", authenticateMcp, async(req,res)=>{
  const transport=new StreamableHTTPServerTransport({sessionIdGenerator:undefined,enableDnsRebindingProtection:true,allowedHosts:[config.issuerUrl.host,"localhost:8789","127.0.0.1:8789"],allowedOrigins:[config.webOrigin]});
  try { const server=await createMcpServer((req as any).mcpAuth); await server.connect(transport); await transport.handleRequest(req,res,req.body); }
  catch(error) { if(!res.headersSent) apiError(res,500,error instanceof Error?error.message:"MCP request failed."); }
});
app.get("/mcp", (_req,res)=>res.status(405).set("Allow","POST").send("Use Streamable HTTP POST for MCP requests."));
app.delete("/mcp", (_req,res)=>res.status(405).set("Allow","POST").send("This server uses stateless Streamable HTTP."));

// Serve compiled frontend in production.
const webRoot=resolve(process.cwd(),"dist/web");
app.get("/healthz", (_req,res)=>res.json({ok:true,service:"volopay-standalone-mcp",resource}));
app.use(express.static(webRoot));
app.use(async(req,res,next)=>{ if(req.method!=="GET" || req.path.startsWith("/api") || req.path.startsWith("/oauth") || req.path.startsWith("/.well-known") || ["/mcp","/authorize","/token","/register"].includes(req.path)) return next(); try { res.type("html").send(await readFile(resolve(webRoot,"index.html"),"utf8")); } catch { res.status(404).send("Frontend not built. Run npm run build."); } });
app.listen(config.port,"0.0.0.0",()=>console.log(`Volopay standalone MCP listening on ${issuer} (resource ${resource})`));
