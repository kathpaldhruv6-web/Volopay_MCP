# Implementation status

## Implemented in this working copy
- Express API with browser login/session lifecycle and CSRF checks.
- OAuth authorization-server discovery and protected-resource metadata.
- Public-client dynamic registration, authorization-code flow, PKCE S256 verification, token exchange, refresh rotation, replay-family revocation, and token revocation.
- React login and OAuth consent UI with workspace and role-aware scope selection.
- Stateless Streamable HTTP MCP endpoint.
- Six read-only finance tools with workspace ID taken exclusively from the validated bearer token.
- Current membership/role revalidation on every MCP request and audit logging for tool calls.
- Synthetic seed users, workspaces, transactions, cards and expenses.
- README, environment example and basic database/PKCE tests.

## Verification performed in this environment
- SQLite schema executed successfully against an in-memory SQLite database.
- TypeScript/TSX files transpiled to JavaScript and emitted JavaScript passed Node syntax checks.
- Package manifest dependencies match the supplied lockfile.

## Verification still required
The package registry was unavailable/time-limited in the implementation environment, so a full dependency installation, TypeScript typecheck, Vite build, Vitest run, and live Claude OAuth/MCP handshake could not be completed here. After downloading this project, run `npm ci`, `npm run typecheck`, `npm test`, and `npm run build` in Codespaces. Treat the app as an assignment demo until those checks and an end-to-end Claude connection are verified.
