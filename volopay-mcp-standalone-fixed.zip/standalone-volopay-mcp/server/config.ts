import { resolve } from "node:path";

const port = Number(process.env.PORT ?? 8789);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error("PORT must be a valid TCP port.");
}

export const config = {
  port,
  issuerUrl: new URL(process.env.ISSUER_URL ?? `http://127.0.0.1:${port}`),
  webOrigin: new URL(process.env.WEB_ORIGIN ?? "http://127.0.0.1:5173").origin,
  databasePath: resolve(process.env.DATABASE_PATH ?? "./data/volopay-demo.sqlite"),
  sessionSecret: process.env.SESSION_SECRET ?? "",
  demoMode: process.env.DEMO_MODE !== "false",
};

const isLoopback = ["localhost", "127.0.0.1", "[::1]"].includes(config.issuerUrl.hostname);
if (config.issuerUrl.protocol !== "https:" && !isLoopback) {
  throw new Error("ISSUER_URL must use HTTPS except for localhost development.");
}
if (!config.demoMode && config.sessionSecret.length < 32) {
  throw new Error("SESSION_SECRET must contain at least 32 characters outside demo mode.");
}
