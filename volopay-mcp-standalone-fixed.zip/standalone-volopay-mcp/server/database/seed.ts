import { randomBytes, scryptSync } from "node:crypto";
import { openDatabase } from "./db.js";

const db = openDatabase();
const passwordHash = (password: string): string => {
  const salt = randomBytes(16);
  const derived = scryptSync(password, salt, 64);
  return `scrypt$${salt.toString("hex")}$${derived.toString("hex")}`;
};

const seed = db.transaction(() => {
  if ((db.prepare("SELECT COUNT(*) AS count FROM users").get() as { count: number }).count) return;

  db.prepare("INSERT INTO users (id, email, display_name, password_hash) VALUES (?, ?, ?, ?)").run(
    "user-alex",
    "alex@example.test",
    "Alex Morgan",
    passwordHash("VolopayDemo!2026"),
  );
  db.prepare("INSERT INTO users (id, email, display_name, password_hash) VALUES (?, ?, ?, ?)").run(
    "user-jamie",
    "jamie@example.test",
    "Jamie Chen",
    passwordHash("ClaudeDemo!2026"),
  );
  db.prepare("INSERT INTO workspaces (id, name, currency) VALUES (?, ?, ?)").run(
    "workspace-northstar",
    "Northstar Design",
    "USD",
  );
  db.prepare("INSERT INTO workspaces (id, name, currency) VALUES (?, ?, ?)").run(
    "workspace-cascade",
    "Cascade Labs",
    "USD",
  );

  const addMember = db.prepare(
    "INSERT INTO workspace_members (user_id, workspace_id, role) VALUES (?, ?, ?)",
  );
  addMember.run("user-alex", "workspace-northstar", "owner");
  addMember.run("user-alex", "workspace-cascade", "viewer");
  addMember.run("user-jamie", "workspace-cascade", "admin");
  addMember.run("user-jamie", "workspace-northstar", "member");

  const addTransaction = db.prepare(
    "INSERT INTO transactions VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
  );
  [
    ["txn-ns-001", "workspace-northstar", "Acme Cloud", 12900, "USD", "Software", "posted", "2026-03-03T14:00:00.000Z"],
    ["txn-ns-002", "workspace-northstar", "Metro Travel", 8425, "USD", "Travel", "posted", "2026-03-04T10:30:00.000Z"],
    ["txn-ns-003", "workspace-northstar", "Paper & Co", 4520, "USD", "Office", "pending", "2026-03-05T09:15:00.000Z"],
    ["txn-cs-001", "workspace-cascade", "Harbor Hosting", 21500, "USD", "Software", "posted", "2026-03-02T18:45:00.000Z"],
    ["txn-cs-002", "workspace-cascade", "Greenline Rail", 6350, "USD", "Travel", "posted", "2026-03-06T08:20:00.000Z"],
  ].forEach((row) => addTransaction.run(...row));

  const addCard = db.prepare("INSERT INTO cards VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  [
    ["card-ns-001", "workspace-northstar", "Alex Morgan", "4242", "physical", "active", 250000, "USD"],
    ["card-ns-002", "workspace-northstar", "Taylor Reed", "1058", "virtual", "locked", 100000, "USD"],
    ["card-cs-001", "workspace-cascade", "Jamie Chen", "8831", "virtual", "active", 300000, "USD"],
  ].forEach((row) => addCard.run(...row));

  const addExpense = db.prepare("INSERT INTO expenses VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
  [
    ["exp-ns-001", "workspace-northstar", "Taylor Reed", "Cloud Summit", 34900, "USD", "Travel", "pending", "2026-03-05T12:00:00.000Z"],
    ["exp-ns-002", "workspace-northstar", "Alex Morgan", "Design Depot", 7299, "USD", "Office", "approved", "2026-03-01T11:00:00.000Z"],
    ["exp-cs-001", "workspace-cascade", "Jamie Chen", "Data Forum", 18400, "USD", "Travel", "pending", "2026-03-06T16:30:00.000Z"],
    ["exp-cs-002", "workspace-cascade", "Morgan Lee", "Bright Media", 9500, "USD", "Marketing", "approved", "2026-02-28T15:00:00.000Z"],
  ].forEach((row) => addExpense.run(...row));
});

seed();
db.close();
console.log("Demo database initialized and seeded.");
