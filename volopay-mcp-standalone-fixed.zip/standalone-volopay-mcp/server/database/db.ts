import Database from "better-sqlite3";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { config } from "../config.js";

export function openDatabase(path = config.databasePath): Database.Database {
  if (path !== ":memory:") mkdirSync(dirname(path), { recursive: true });
  const db = new Database(path);
  db.pragma("foreign_keys = ON");
  db.pragma("journal_mode = WAL");
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS workspaces (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      currency TEXT NOT NULL DEFAULT 'USD'
    );
    CREATE TABLE IF NOT EXISTS workspace_members (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
      role TEXT NOT NULL CHECK (role IN ('owner', 'admin', 'member', 'viewer')),
      active INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
      PRIMARY KEY (user_id, workspace_id)
    );
    CREATE TABLE IF NOT EXISTS oauth_clients (
      client_id TEXT PRIMARY KEY,
      client_json TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS browser_sessions (
      session_hash TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
      csrf_token TEXT NOT NULL,
      expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS pending_authorizations (
      request_hash TEXT PRIMARY KEY,
      client_id TEXT NOT NULL REFERENCES oauth_clients(client_id) ON DELETE CASCADE,
      redirect_uri TEXT NOT NULL,
      state TEXT,
      code_challenge TEXT NOT NULL,
      requested_scopes TEXT NOT NULL,
      resource TEXT NOT NULL,
      expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS authorization_codes (
      code_hash TEXT PRIMARY KEY,
      client_id TEXT NOT NULL REFERENCES oauth_clients(client_id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
      redirect_uri TEXT NOT NULL,
      code_challenge TEXT NOT NULL,
      scopes TEXT NOT NULL,
      resource TEXT NOT NULL,
      expires_at INTEGER NOT NULL,
      consumed_at INTEGER
    );
    CREATE TABLE IF NOT EXISTS access_tokens (
      token_hash TEXT PRIMARY KEY,
      family_id TEXT NOT NULL,
      client_id TEXT NOT NULL REFERENCES oauth_clients(client_id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
      scopes TEXT NOT NULL,
      resource TEXT NOT NULL,
      expires_at INTEGER NOT NULL,
      revoked_at INTEGER
    );
    CREATE INDEX IF NOT EXISTS access_tokens_family_idx ON access_tokens(family_id);
    CREATE TABLE IF NOT EXISTS refresh_tokens (
      token_hash TEXT PRIMARY KEY,
      family_id TEXT NOT NULL,
      client_id TEXT NOT NULL REFERENCES oauth_clients(client_id) ON DELETE CASCADE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
      scopes TEXT NOT NULL,
      resource TEXT NOT NULL,
      expires_at INTEGER NOT NULL,
      consumed_at INTEGER,
      revoked_at INTEGER
    );
    CREATE INDEX IF NOT EXISTS refresh_tokens_family_idx ON refresh_tokens(family_id);
    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
      merchant TEXT NOT NULL,
      amount_minor INTEGER NOT NULL,
      currency TEXT NOT NULL,
      category TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('pending', 'posted', 'declined', 'reversed')),
      occurred_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS transactions_workspace_date_idx ON transactions(workspace_id, occurred_at DESC);
    CREATE TABLE IF NOT EXISTS cards (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
      holder_name TEXT NOT NULL,
      last_four TEXT NOT NULL,
      card_type TEXT NOT NULL CHECK (card_type IN ('physical', 'virtual')),
      status TEXT NOT NULL CHECK (status IN ('active', 'locked', 'cancelled')),
      monthly_limit_minor INTEGER NOT NULL,
      currency TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS expenses (
      id TEXT PRIMARY KEY,
      workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
      submitter_name TEXT NOT NULL,
      merchant TEXT NOT NULL,
      amount_minor INTEGER NOT NULL,
      currency TEXT NOT NULL,
      category TEXT NOT NULL,
      approval_status TEXT NOT NULL CHECK (approval_status IN ('pending', 'approved', 'rejected')),
      submitted_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS expenses_workspace_status_idx ON expenses(workspace_id, approval_status, submitted_at DESC);
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL REFERENCES users(id),
      workspace_id TEXT NOT NULL REFERENCES workspaces(id),
      tool_name TEXT NOT NULL,
      occurred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      outcome TEXT NOT NULL CHECK (outcome IN ('success', 'denied', 'error')),
      request_id TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS audit_logs_occurred_idx ON audit_logs(occurred_at DESC);
  `);
  return db;
}

export type WorkspaceRole = "owner" | "admin" | "member" | "viewer";
export type Scope =
  | "workspace:read"
  | "transactions:read"
  | "cards:read"
  | "expenses:read"
  | "reports:read";

export const ALL_SCOPES: Scope[] = [
  "workspace:read",
  "transactions:read",
  "cards:read",
  "expenses:read",
  "reports:read",
];

export const ROLE_SCOPES: Record<WorkspaceRole, Scope[]> = {
  owner: ALL_SCOPES,
  admin: ALL_SCOPES,
  member: ["workspace:read", "transactions:read", "expenses:read", "reports:read"],
  viewer: ["workspace:read", "transactions:read", "reports:read"],
};

export function membershipRole(
  db: Database.Database,
  userId: string,
  workspaceId: string,
): WorkspaceRole | undefined {
  const row = db
    .prepare(
      "SELECT role FROM workspace_members WHERE user_id = ? AND workspace_id = ? AND active = 1",
    )
    .get(userId, workspaceId) as { role: WorkspaceRole } | undefined;
  return row?.role;
}
