import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import type { NextFunction, Request, Response } from "express";
import type Database from "better-sqlite3";
import { config } from "../config.js";

const COOKIE_NAME = "volopay_demo_session";
const SESSION_SECONDS = 2 * 60 * 60;

export type BrowserSession = {
  userId: string | null;
  csrfToken: string;
};

declare global {
  namespace Express {
    interface Request {
      browserSession?: BrowserSession;
      rawSessionId?: string;
    }
  }
}

export const sha256 = (value: string): string =>
  createHmac("sha256", config.sessionSecret || "local-demo-only-pepper").update(value, "utf8").digest("hex");

function getCookie(req: Request): string | undefined {
  const header = req.headers.cookie;
  if (!header) return undefined;
  const entry = header.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${COOKIE_NAME}=`));
  if (!entry) return undefined;
  try {
    return decodeURIComponent(entry.slice(COOKIE_NAME.length + 1));
  } catch {
    return undefined;
  }
}

function setSessionCookie(res: Response, sessionId: string): void {
  const secure = config.issuerUrl.protocol === "https:" ? "; Secure" : "";
  res.setHeader(
    "Set-Cookie",
    `${COOKIE_NAME}=${encodeURIComponent(sessionId)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_SECONDS}${secure}`,
  );
}

export function clearSessionCookie(res: Response): void {
  const secure = config.issuerUrl.protocol === "https:" ? "; Secure" : "";
  res.setHeader(
    "Set-Cookie",
    `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`,
  );
}

export function createBrowserSession(
  db: Database.Database,
  res: Response,
  userId: string | null,
): BrowserSession {
  const sessionId = randomBytes(32).toString("base64url");
  const csrfToken = randomBytes(32).toString("base64url");
  const expiresAt = Math.floor(Date.now() / 1000) + SESSION_SECONDS;
  db.prepare(
    "INSERT INTO browser_sessions (session_hash, user_id, csrf_token, expires_at) VALUES (?, ?, ?, ?)",
  ).run(sha256(sessionId), userId, csrfToken, expiresAt);
  setSessionCookie(res, sessionId);
  return { userId, csrfToken };
}

export function browserSessionMiddleware(db: Database.Database) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    const rawSessionId = getCookie(req);
    if (rawSessionId) {
      const session = db
        .prepare(
          "SELECT user_id AS userId, csrf_token AS csrfToken FROM browser_sessions WHERE session_hash = ? AND expires_at > ?",
        )
        .get(sha256(rawSessionId), Math.floor(Date.now() / 1000)) as BrowserSession | undefined;
      if (session) {
        req.browserSession = session;
        req.rawSessionId = rawSessionId;
      }
    }
    next();
  };
}

export function requireBrowserSession(req: Request, res: Response): BrowserSession | undefined {
  if (!req.browserSession) {
    res.status(401).json({ error: "Sign in to continue." });
    return undefined;
  }
  return req.browserSession;
}

export function requireCsrf(req: Request, res: Response): boolean {
  const session = req.browserSession;
  const origin = req.get("origin");
  const supplied = req.body?.csrfToken;
  if (
    !session ||
    !req.rawSessionId ||
    !origin ||
    origin !== config.webOrigin ||
    typeof supplied !== "string" ||
    supplied.length !== session.csrfToken.length ||
    !timingSafeEqual(Buffer.from(supplied), Buffer.from(session.csrfToken))
  ) {
    res.status(403).json({ error: "Request could not be verified. Reload and try again." });
    return false;
  }
  return true;
}

export function verifyPassword(password: string, encoded: string): boolean {
  const [algorithm, saltHex, digestHex] = encoded.split("$");
  if (algorithm !== "scrypt" || !saltHex || !digestHex) return false;
  const expected = Buffer.from(digestHex, "hex");
  const actual = scryptSync(password, Buffer.from(saltHex, "hex"), expected.length);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
