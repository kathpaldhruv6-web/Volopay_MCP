import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  root: "web",
  server: {
    host: "0.0.0.0",
    proxy: {
      "/api": "http://127.0.0.1:8789",
      "/oauth": "http://127.0.0.1:8789",
      "/.well-known": "http://127.0.0.1:8789",
      "/interaction": "http://127.0.0.1:8789",
      "/mcp": "http://127.0.0.1:8789",
    },
  },
  build: {
    outDir: "../dist/web",
    emptyOutDir: true,
  },
});
