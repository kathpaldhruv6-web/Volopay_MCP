import { describe, expect, it } from "vitest";
import { createHash, randomBytes } from "node:crypto";

describe("OAuth PKCE primitives", () => {
  it("generates an S256 challenge from a verifier", () => {
    const verifier = randomBytes(32).toString("base64url");
    const challenge = createHash("sha256").update(verifier).digest("base64url");
    expect(verifier.length).toBeGreaterThanOrEqual(43);
    expect(challenge).toMatch(/^[A-Za-z0-9_-]{43}$/);
    expect(challenge).not.toBe(verifier);
  });
});
