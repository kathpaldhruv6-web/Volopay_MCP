import { afterEach, describe, expect, it } from "vitest";
import { openDatabase, membershipRole, ROLE_SCOPES } from "../server/database/db.js";

let db: ReturnType<typeof openDatabase> | undefined;
afterEach(() => { db?.close(); db = undefined; });

describe("workspace authorization primitives", () => {
  it("returns only active membership roles", () => {
    db = openDatabase(":memory:");
    db.exec(`INSERT INTO users(id,email,display_name,password_hash) VALUES ('u1','u1@test','User','x');
      INSERT INTO workspaces(id,name) VALUES ('w1','One'),('w2','Two');
      INSERT INTO workspace_members(user_id,workspace_id,role,active) VALUES ('u1','w1','owner',1),('u1','w2','viewer',0);`);
    expect(membershipRole(db, "u1", "w1")).toBe("owner");
    expect(membershipRole(db, "u1", "w2")).toBeUndefined();
  });
  it("keeps finance records separated by workspace IDs", () => {
    db = openDatabase(":memory:");
    db.exec(`INSERT INTO users(id,email,display_name,password_hash) VALUES ('u1','u1@test','User','x');
      INSERT INTO workspaces(id,name) VALUES ('w1','One'),('w2','Two');
      INSERT INTO transactions(id,workspace_id,merchant,amount_minor,currency,category,status,occurred_at)
        VALUES ('t1','w1','Only One',100,'USD','Office','posted','2026-01-01'),('t2','w2','Only Two',200,'USD','Office','posted','2026-01-02');`);
    const rows = db.prepare("SELECT id FROM transactions WHERE workspace_id=?").all("w1") as Array<{id:string}>;
    expect(rows.map(row => row.id)).toEqual(["t1"]);
  });
  it("keeps viewer permissions read-only and limited", () => {
    expect(ROLE_SCOPES.viewer).toEqual(["workspace:read", "transactions:read", "reports:read"]);
    expect(ROLE_SCOPES.viewer).not.toContain("cards:read");
    expect(ROLE_SCOPES.viewer).not.toContain("expenses:read");
  });
});
