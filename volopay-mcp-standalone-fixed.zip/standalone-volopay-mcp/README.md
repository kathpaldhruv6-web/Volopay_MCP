# Volopay Standalone MCP Demo

A self-contained demo of a multi-workspace finance MCP server with OAuth authorization, PKCE S256, rotating refresh tokens, workspace-scoped tools, and a small React consent/login UI. It uses synthetic data only.

## Requirements
- Node.js 20.19+ (or 22.12+)
- npm

## Run locally

```bash
npm install
cp .env.example .env
npm run db:init
npm run dev
```

Open http://127.0.0.1:5173. The API/MCP issuer runs at http://127.0.0.1:8789 and the MCP resource is http://127.0.0.1:8789/mcp.

### Demo users
- Alex Morgan: `alex@example.test` / `VolopayDemo!2026`
- Jamie Chen: `jamie@example.test` / `ClaudeDemo!2026`

The demo database is seeded with two synthetic workspaces: Northstar Design and Cascade Labs. Alex is owner of Northstar and viewer of Cascade; Jamie is admin of Cascade and member of Northstar.

## Claude connection
Use a remote MCP connector with the server URL `http://127.0.0.1:8789/mcp` only when the MCP client can reach your machine (for example through a secure HTTPS tunnel). For a real remote Claude connection, deploy behind HTTPS and set `ISSUER_URL` to the public HTTPS origin and `WEB_ORIGIN` to the public UI origin. OAuth metadata and dynamic client registration are exposed at the standard well-known and `/register` endpoints.

## MCP tools
- `get_workspace` — current authorized workspace details (`workspace:read`)
- `list_transactions` — workspace transactions (`transactions:read`)
- `get_transaction` — one transaction, always constrained by workspace (`transactions:read`)
- `list_cards` — masked card details (`cards:read`)
- `list_expenses` — expense submissions (`expenses:read`)
- `get_spending_summary` — grouped spend summary (`reports:read`)

All tools use the workspace ID from the validated access token, never from tool arguments. Workspace membership and role scopes are rechecked for every MCP request.

## Security notes and limitations
- This is an assignment/demo implementation, not a production financial system.
- HTTPS is required for non-loopback issuer URLs. Do not expose the demo credentials publicly.
- OAuth clients are public clients using Authorization Code + PKCE S256.
- Access tokens last 15 minutes; refresh tokens last 30 days and rotate on use. Reuse revokes the complete token family.
- SQLite stores token hashes, not raw bearer tokens.
- The demo includes read-only finance tools; it cannot move money, create cards, approve expenses, or modify financial records.
- Production deployment should add rate limiting, operational monitoring, backup/restore, formal security review, and a deliberate account lifecycle/reset strategy.

## Build and test

```bash
npm run typecheck
npm run build
npm test
```

`npm run db:init` is idempotent and only seeds an empty database.

## GitHub Codespaces notes

For a Codespaces preview, forward ports **5173** and **8789**. Set both to HTTPS/public if you intend to let an external MCP client reach the server. Copy the forwarded URL for each port and update `.env`:

```dotenv
WEB_ORIGIN=https://YOUR-CODESPACE-5173.app.github.dev
ISSUER_URL=https://YOUR-CODESPACE-8789.app.github.dev
PORT=8789
```

Restart the dev server after changing `.env`. Open the 5173 forwarded URL for the UI. The UI displays the 8789 `/mcp` endpoint for your MCP client. Do not publish the demo credentials or use this demo with real financial data.

Before public hosting, set `DEMO_MODE=false` and replace `SESSION_SECRET` with a randomly generated value of at least 32 characters. The secret is used as a keyed hash for stored session identifiers, authorization codes, and token digests. Changing it invalidates existing browser sessions and OAuth tokens, so rotate it deliberately.
