# Volopay Backend API — v0.6

Authenticated HTTP API foundation for Volopay onboarding operations. This package is the Agent 2 backend source; it does not include the Agent 1 MCP server or frontend application.

## Setup

1. Copy `.env.example` to `.env` and fill in local Supabase URL, anon key and a random `CURSOR_HMAC_SECRET` (at least 32 characters). Never commit `.env` or share credentials in chat.
2. Install dependencies with `npm install` (this package does not include a lockfile yet).
3. Run `npm run typecheck`, `npm run build`, and `npm run test:static`.
4. Apply migrations only to a disposable development database after reviewing them.

## v0.5 change

The old static contract test expected a `501 NOT_IMPLEMENTED` proposal placeholder. That expectation became stale in v0.4 when proposal submission, approval and rejection were implemented through database RPCs. v0.5 updates the test to assert those current routes and records the validation limits in `docs/STATUS_v0.5.md`.

## Safety boundary

The API verifies Supabase bearer tokens and workspace membership, and uses a request-scoped anon-key client with the user's JWT. It does not use a service-role key. Do not connect Agent 1 until delegated end-user identity is verified end-to-end.

## v0.6 change

Proposal payloads now use strict per-kind/per-operation Zod schemas instead of accepting arbitrary JSON objects. The database RPC also rejects empty payloads and supports explicit null-clearing for nullable fields on update. See `docs/CHANGELOG_v0.6.md` and `docs/STATUS_v0.6.md`.

## What may need your action later

No login or account action is needed to review this package. When you are ready to run it locally, you will need Node.js/npm and your own Supabase project URL plus public anon key in a local `.env` file. For real database verification, create a disposable development Supabase project and run the reviewed migrations there. Never send credentials or keys in chat; never use the service-role key for this app.
