# Volopay Backend API — v0.6 manifest

Authoritative backend package for the current build stage.

## Source of truth
- `src/proposal-validation.ts` — strict proposal validation added in v0.6.
- `src/routes.ts` — authenticated HTTP routes; proposal endpoint uses shared strict schema.
- `supabase/migrations/` — initial schema, RLS/integrity and proposal transaction migrations.
- `tests/` — static contract and proposal guard checks.

## Versioning rule
Keep this package as the current corrected source. Inline comments and `docs/CHANGELOG_v0.6.md` describe changes from v0.5. Do not keep parallel working copies unless a release or rollback snapshot is explicitly needed.

## Dependencies
Node.js 20+ and npm. Runtime packages are declared in `package.json`; `npm install` is required on the user's machine or a network-enabled build runner.

## Safety
No production secrets are included. Never commit `.env`, JWTs, Supabase service-role keys, or user data. Use a disposable test project for migration verification.
