import type { Request, Response, NextFunction } from 'express';
import { db } from './db/db.js';

export type Role = 'Admin' | 'Implementation Manager' | 'Team Member';
export interface Identity { userId: string; email: string; displayName: string; workspaceId: string; role: Role; }

declare global { namespace Express { interface Request { identity?: Identity } } }

// LOCAL DEMO ONLY. This header is caller-controlled and is NOT authentication.
// Production must replace this module with Supabase JWT verification (JWKS, exact iss/aud/exp)
// and must forward the signed end-user token to the MCP-facing backend.
export function authenticate(req: Request, res: Response, next: NextFunction) {
  if (process.env.DEMO_AUTH === 'false') return res.status(503).json({ error: { code: 'AUTH_NOT_CONFIGURED', message: 'Configure verified Supabase JWT authentication before use.' } });
  const userId = String(req.header('x-demo-user-id') ?? req.header('authorization')?.replace(/^Bearer demo:/, '') ?? '');
  const row = db.prepare(`SELECT u.id userId,u.email,u.display_name displayName,m.workspace_id workspaceId,m.role
    FROM users u JOIN memberships m ON m.user_id=u.id AND m.status='active'
    WHERE u.id=? ORDER BY m.workspace_id LIMIT 1`).get(userId) as any;
  if (!row) return res.status(401).json({ error: { code: 'AUTH_REQUIRED', message: 'Select a valid local demo user.' } });
  req.identity = row as Identity;
  next();
}
export function requireRole(...roles: Role[]) { return (req: Request,res: Response,next: NextFunction) => {
  if (!req.identity || !roles.includes(req.identity.role)) return res.status(403).json({ error: { code:'PERMISSION_DENIED', message:'You do not have permission to perform this action.' } });
  next();
}; }
export function canAccessOnboarding(identity: Identity, onboardingId: string): boolean {
  if (identity.role !== 'Team Member') return Boolean(db.prepare('SELECT 1 FROM onboardings WHERE id=? AND workspace_id=?').get(onboardingId,identity.workspaceId));
  return Boolean(db.prepare(`SELECT 1 FROM onboarding_memberships om JOIN onboardings o ON o.id=om.onboarding_id WHERE om.onboarding_id=? AND om.user_id=? AND o.workspace_id=?`).get(onboardingId,identity.userId,identity.workspaceId));
}
