import { createHash, randomUUID } from 'node:crypto';
import { db } from './db/db.js';
import type { Identity } from './auth.js';

const now = () => new Date().toISOString();
const audit = (identity: Identity, action: string, type: string, id: string, metadata: object = {}) => db.prepare(`INSERT INTO audit_events(id,workspace_id,actor_id,action,entity_type,entity_id,metadata,created_at) VALUES(?,?,?,?,?,?,?,?)`).run(randomUUID(),identity.workspaceId,identity.userId,action,type,id,JSON.stringify(metadata),now());
export const safeOnboarding = (row:any) => ({id:row.id,customer:{id:row.customer_id,display_name:row.customer_name},name:row.name,status:row.status,owner_display_name:row.owner_label,start_date:row.start_date,target_date:row.target_date,updated_at:row.updated_at,version:row.version});
export function listOnboardings(identity:Identity, status?:string) {
 const sql=`SELECT o.*,c.display_name customer_name FROM onboardings o JOIN customers c ON c.id=o.customer_id WHERE o.workspace_id=? ${identity.role==='Team Member'?'AND EXISTS(SELECT 1 FROM onboarding_memberships om WHERE om.onboarding_id=o.id AND om.user_id=?)':''} ${status?'AND o.status=?':''} ORDER BY o.updated_at DESC,o.id LIMIT 100`;
 const params:any[]=[identity.workspaceId]; if(identity.role==='Team Member')params.push(identity.userId); if(status)params.push(status);
 return (db.prepare(sql).all(...params) as any[]).map(safeOnboarding);
}
export function searchRecords(identity:Identity,q='') {
 const like=`%${q.slice(0,200)}%`;
 const allowed=identity.role==='Team Member'?'AND EXISTS(SELECT 1 FROM onboarding_memberships om WHERE om.onboarding_id=t.onboarding_id AND om.user_id=?)':'';
 const tasks=db.prepare(`SELECT t.id,'task' type,t.onboarding_id,t.title,t.status,t.due_date,t.version FROM tasks t WHERE t.workspace_id=? AND t.title LIKE ? ${allowed} ORDER BY t.due_date LIMIT 100`).all(identity.workspaceId,like,...(identity.role==='Team Member'?[identity.userId]:[]));
 const com=db.prepare(`SELECT c.id,'commitment' type,c.onboarding_id,c.title,c.status,c.due_date,c.version FROM commitments c WHERE c.workspace_id=? AND c.title LIKE ? ${identity.role==='Team Member'?'AND EXISTS(SELECT 1 FROM onboarding_memberships om WHERE om.onboarding_id=c.onboarding_id AND om.user_id=?)':''} ORDER BY c.due_date LIMIT 100`).all(identity.workspaceId,like,...(identity.role==='Team Member'?[identity.userId]:[]));
 return [...tasks,...com];
}
export function onboardingSummary(identity:Identity,id:string) {
 const row=db.prepare(`SELECT o.*,c.display_name customer_name FROM onboardings o JOIN customers c ON c.id=o.customer_id WHERE o.id=? AND o.workspace_id=?`).get(id,identity.workspaceId) as any;
 if(!row || (identity.role==='Team Member' && !db.prepare('SELECT 1 FROM onboarding_memberships WHERE onboarding_id=? AND user_id=?').get(id,identity.userId))) return null;
 const openTasks=(db.prepare(`SELECT COUNT(*) n FROM tasks WHERE onboarding_id=? AND status IN ('Open','In Progress')`).get(id) as any).n;
 const openCommitments=(db.prepare(`SELECT COUNT(*) n FROM commitments WHERE onboarding_id=? AND status IN ('Open','In Progress')`).get(id) as any).n;
 const overdue=(db.prepare(`SELECT COUNT(*) n FROM tasks WHERE onboarding_id=? AND status IN ('Open','In Progress') AND due_date < date('now')`).get(id) as any).n + (db.prepare(`SELECT COUNT(*) n FROM commitments WHERE onboarding_id=? AND status IN ('Open','In Progress') AND due_date < date('now')`).get(id) as any).n;
 const recent=db.prepare(`SELECT id,'event' type,title,occurred_at FROM events WHERE onboarding_id=? ORDER BY occurred_at DESC LIMIT 5`).all(id);
 return {onboarding_id:id,status:row.status,open_commitments:openCommitments,open_tasks:openTasks,overdue_items:overdue,recent_activity:recent};
}
export function getCommitments(identity:Identity,id:string){ if(!hasAccess(identity,id))return null; return db.prepare(`SELECT id,onboarding_id,title,status,owner_role_label,due_date,version,updated_at FROM commitments WHERE onboarding_id=? AND workspace_id=? ORDER BY due_date LIMIT 100`).all(id,identity.workspaceId); }
export function getTasks(identity:Identity,id:string){ if(!hasAccess(identity,id))return null; return db.prepare(`SELECT id,onboarding_id,title,status,priority,owner_role_label,due_date,version,updated_at FROM tasks WHERE onboarding_id=? AND workspace_id=? ORDER BY due_date LIMIT 100`).all(id,identity.workspaceId); }
export function getOverdue(identity:Identity,asOf=new Date().toISOString().slice(0,10)){
 const memberFilter=identity.role==='Team Member'?'AND EXISTS(SELECT 1 FROM onboarding_memberships om WHERE om.onboarding_id=x.onboarding_id AND om.user_id=?)':'';
 return db.prepare(`SELECT * FROM (SELECT id,'task' type,onboarding_id,title,status,due_date FROM tasks UNION ALL SELECT id,'commitment' type,onboarding_id,title,status,due_date FROM commitments) x WHERE x.status IN ('Open','In Progress') AND x.due_date < ? AND x.onboarding_id IN (SELECT id FROM onboardings WHERE workspace_id=?) ${memberFilter} ORDER BY due_date LIMIT 100`).all(asOf,identity.workspaceId,...(identity.role==='Team Member'?[identity.userId]:[]));
}
export function getActivity(identity:Identity){
 if(identity.role!=='Team Member') return db.prepare(`SELECT id,action,entity_type,entity_id,created_at FROM audit_events WHERE workspace_id=? ORDER BY created_at DESC LIMIT 100`).all(identity.workspaceId);
 return db.prepare(`SELECT a.id,a.action,a.entity_type,a.entity_id,a.created_at FROM audit_events a WHERE a.workspace_id=? AND (
  (a.entity_type='onboarding' AND a.entity_id IN (SELECT onboarding_id FROM onboarding_memberships WHERE user_id=?)) OR
  (a.entity_type='task' AND a.entity_id IN (SELECT t.id FROM tasks t JOIN onboarding_memberships om ON om.onboarding_id=t.onboarding_id WHERE om.user_id=?)) OR
  (a.entity_type='commitment' AND a.entity_id IN (SELECT c.id FROM commitments c JOIN onboarding_memberships om ON om.onboarding_id=c.onboarding_id WHERE om.user_id=?)) OR
  (a.entity_type='event' AND a.entity_id IN (SELECT e.id FROM events e JOIN onboarding_memberships om ON om.onboarding_id=e.onboarding_id WHERE om.user_id=?)) OR
  (a.entity_type='decision' AND a.entity_id IN (SELECT d.id FROM decisions d JOIN onboarding_memberships om ON om.onboarding_id=d.onboarding_id WHERE om.user_id=?))
 ) ORDER BY a.created_at DESC LIMIT 100`).all(identity.workspaceId,identity.userId,identity.userId,identity.userId,identity.userId,identity.userId);
}
export function hasAccess(identity:Identity,id:string){ return identity.role!=='Team Member' ? Boolean(db.prepare('SELECT 1 FROM onboardings WHERE id=? AND workspace_id=?').get(id,identity.workspaceId)) : Boolean(db.prepare('SELECT 1 FROM onboarding_memberships om JOIN onboardings o ON o.id=om.onboarding_id WHERE om.onboarding_id=? AND om.user_id=? AND o.workspace_id=?').get(id,identity.userId,identity.workspaceId)); }
export function submitProposal(identity:Identity,input:any,key:string){
 if(!hasAccess(identity,input.target_onboarding_id))throw new Error('RESOURCE_NOT_FOUND');
 if(!['event','commitment','task','decision'].includes(input.kind)||!['create','update'].includes(input.operation))throw new Error('VALIDATION_ERROR');
 const allowed=input.kind==='event'?['title','event_type','occurred_at','record_id']:input.kind==='commitment'?['title','status','due_date','owner_role_label','record_id']:input.kind==='task'?['title','status','priority','due_date','owner_role_label','record_id']:['title','decision_status','decided_at','record_id'];
 if(!input.payload||typeof input.payload.title!=='string'||!input.payload.title.trim()||input.payload.title.length>200||Object.keys(input.payload).some((k:string)=>!allowed.includes(k)))throw new Error('VALIDATION_ERROR');
 if(input.operation==='update'&&(!Number.isInteger(input.base_record_version)||input.base_record_version<1||typeof input.payload.record_id!=='string'))throw new Error('VALIDATION_ERROR');
 if(input.operation==='create'&&input.payload.record_id!==undefined)throw new Error('VALIDATION_ERROR');
 const hash=createHash('sha256').update(JSON.stringify(input)).digest('hex');
 const existing=db.prepare('SELECT * FROM proposals WHERE workspace_id=? AND proposer_id=? AND idempotency_key=?').get(identity.workspaceId,identity.userId,key) as any;
 if(existing){if(existing.request_hash!==hash)throw new Error('IDEMPOTENCY_KEY_REUSED');return {...existing,payload:JSON.parse(existing.payload),replayed:true};}
 const id=randomUUID(),stamp=now();
 db.prepare(`INSERT INTO proposals(id,workspace_id,onboarding_id,proposer_id,kind,operation,payload,base_record_version,status,idempotency_key,request_hash,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id,identity.workspaceId,input.target_onboarding_id,identity.userId,input.kind,input.operation,JSON.stringify(input.payload),input.base_record_version??null,'PENDING',key,hash,stamp,stamp);
 audit(identity,'PROPOSAL_SUBMITTED','proposal',id,{kind:input.kind,operation:input.operation});
 return db.prepare('SELECT * FROM proposals WHERE id=?').get(id) as any;
}
export function listProposals(identity:Identity){return db.prepare(`SELECT p.id,p.onboarding_id,p.kind,p.operation,p.status,p.created_at,u.display_name proposer,p.payload FROM proposals p JOIN users u ON u.id=p.proposer_id WHERE p.workspace_id=? ORDER BY p.created_at DESC LIMIT 100`).all(identity.workspaceId).map((p:any)=>({...p,payload:JSON.parse(p.payload)}));}
export function reviewProposal(identity:Identity,id:string,action:'approve'|'reject',reason=''){
 if(!['Admin','Implementation Manager'].includes(identity.role))throw new Error('PERMISSION_DENIED');
 const tx=db.transaction(()=>{
  const p=db.prepare('SELECT * FROM proposals WHERE id=? AND workspace_id=?').get(id,identity.workspaceId) as any;
  if(!p)throw new Error('RESOURCE_NOT_FOUND'); if(p.proposer_id===identity.userId)throw new Error('PROPOSAL_ACTION_FORBIDDEN'); if(p.status!=='PENDING')throw new Error('PROPOSAL_STATE_CONFLICT');
  if(action==='reject'){db.prepare(`UPDATE proposals SET status='REJECTED',reason=?,updated_at=? WHERE id=?`).run(reason||'Rejected by approver',now(),id);audit(identity,'PROPOSAL_REJECTED','proposal',id,{});return;}
  const payload=JSON.parse(p.payload); const recordId=randomUUID(); const stamp=now();
  if(p.operation==='update'){
   const table=p.kind==='event'?'events':p.kind==='task'?'tasks':p.kind==='commitment'?'commitments':'decisions';
   const row=db.prepare(`SELECT * FROM ${table} WHERE id=? AND workspace_id=? AND onboarding_id=?`).get(payload.record_id,identity.workspaceId,p.onboarding_id) as any;
   if(!row)throw new Error('RESOURCE_NOT_FOUND');
   if(row.version!==p.base_record_version){db.prepare(`UPDATE proposals SET status='NEEDS_REVIEW',updated_at=? WHERE id=?`).run(stamp,id);return 'STALE' as const;}
   const allowed=p.kind==='event'?['title','event_type','occurred_at']:p.kind==='commitment'?['title','status','due_date','owner_role_label']:p.kind==='task'?['title','status','priority','due_date','owner_role_label']:['title','decision_status','decided_at'];
   const patch=Object.fromEntries(Object.entries(payload).filter(([k])=>allowed.includes(k)));
   const sets=Object.keys(patch).map(k=>`${k}=@${k}`).join(',');
   db.prepare(`UPDATE ${table} SET ${sets},version=version+1${p.kind==='event'?'':',updated_at=@updated_at'} WHERE id=@id AND workspace_id=@workspace_id AND version=@version`).run({...patch,updated_at:stamp,id:row.id,workspace_id:identity.workspaceId,version:p.base_record_version});
  } else if(p.kind==='event')db.prepare(`INSERT INTO events(id,workspace_id,onboarding_id,title,event_type,occurred_at,created_at) VALUES(?,?,?,?,?,?,?)`).run(recordId,identity.workspaceId,p.onboarding_id,payload.title,payload.event_type,payload.occurred_at??stamp,stamp);
  else if(p.kind==='task')db.prepare(`INSERT INTO tasks(id,workspace_id,onboarding_id,title,status,priority,due_date,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)`).run(recordId,identity.workspaceId,p.onboarding_id,payload.title,payload.status??'Open',payload.priority??'Normal',payload.due_date??null,stamp,stamp);
  else if(p.kind==='commitment')db.prepare(`INSERT INTO commitments(id,workspace_id,onboarding_id,title,status,due_date,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)`).run(recordId,identity.workspaceId,p.onboarding_id,payload.title,payload.status??'Open',payload.due_date??null,stamp,stamp);
  else if(p.kind==='decision')db.prepare(`INSERT INTO decisions(id,workspace_id,onboarding_id,title,decision_status,decided_at,created_at) VALUES(?,?,?,?,?,?,?)`).run(recordId,identity.workspaceId,p.onboarding_id,payload.title,payload.decision_status??'Confirmed',payload.decided_at??stamp,stamp);
  db.prepare(`UPDATE proposals SET status='APPROVED',reason=?,updated_at=? WHERE id=?`).run(`Created record ${recordId}`,stamp,id);
  audit(identity,'PROPOSAL_APPROVED','proposal',id,{record_id:recordId,kind:p.kind});
 }); const result=tx(); if(result==='STALE')throw new Error('PROPOSAL_STATE_CONFLICT');
}
export function createHumanComment(identity:Identity,onboardingId:string,parentType:string,parentId:string,body:string){if(!hasAccess(identity,onboardingId))throw new Error('RESOURCE_NOT_FOUND');const id=randomUUID();db.prepare(`INSERT INTO comments(id,workspace_id,onboarding_id,parent_type,parent_id,author_id,body,created_at) VALUES(?,?,?,?,?,?,?,?)`).run(id,identity.workspaceId,onboardingId,parentType,parentId,identity.userId,body,now());audit(identity,'COMMENT_CREATED','comment',id,{});return {id};}
export function getComments(identity:Identity,onboardingId:string){if(!hasAccess(identity,onboardingId))return null;return db.prepare(`SELECT c.id,c.parent_type,c.parent_id,c.body,c.created_at,u.display_name author FROM comments c JOIN users u ON u.id=c.author_id WHERE c.onboarding_id=? AND c.workspace_id=? ORDER BY c.created_at`).all(onboardingId,identity.workspaceId);}
export function createOnboarding(identity:Identity,input:any){if(!['Admin','Implementation Manager'].includes(identity.role))throw new Error('PERMISSION_DENIED');const id=randomUUID(),customerId=randomUUID(),stamp=now();const tx=db.transaction(()=>{db.prepare('INSERT INTO customers(id,workspace_id,display_name) VALUES(?,?,?)').run(customerId,identity.workspaceId,input.customer_name);db.prepare(`INSERT INTO onboardings(id,workspace_id,customer_id,name,status,owner_label,start_date,target_date,summary,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(id,identity.workspaceId,customerId,input.name,input.status??'Active',input.owner_label??'Implementation Manager',input.start_date??null,input.target_date??null,input.summary??'',stamp,stamp);db.prepare('INSERT INTO onboarding_memberships(onboarding_id,user_id) VALUES(?,?)').run(id,identity.userId);audit(identity,'ONBOARDING_CREATED','onboarding',id,{});});tx();return {id,customer_id:customerId};}
export function updateRecord(identity:Identity,type:string,id:string,version:number,patch:any){if(!['Admin','Implementation Manager','Team Member'].includes(identity.role))throw new Error('PERMISSION_DENIED');const table=type==='task'?'tasks':type==='commitment'?'commitments':null;if(!table)throw new Error('VALIDATION_ERROR');const row=db.prepare(`SELECT * FROM ${table} WHERE id=? AND workspace_id=?`).get(id,identity.workspaceId) as any;if(!row || !hasAccess(identity,row.onboarding_id))throw new Error('RESOURCE_NOT_FOUND');if(row.version!==version)throw new Error('RECORD_VERSION_CONFLICT');const allowed=type==='task'?['title','status','priority','due_date']:['title','status','due_date'];const fields=Object.keys(patch).filter(k=>allowed.includes(k));if(!fields.length)throw new Error('VALIDATION_ERROR');const set=fields.map(f=>`${f}=@${f}`).join(',');db.prepare(`UPDATE ${table} SET ${set},version=version+1,updated_at=@updated_at WHERE id=@id AND workspace_id=@workspace_id AND version=@version`).run({...patch,updated_at:now(),id,workspace_id:identity.workspaceId,version});audit(identity,'RECORD_UPDATED',type,id,{fields});return db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(id);}
export function getWorkspace(identity:Identity){return db.prepare('SELECT id,name,timezone FROM workspaces WHERE id=?').get(identity.workspaceId);}
