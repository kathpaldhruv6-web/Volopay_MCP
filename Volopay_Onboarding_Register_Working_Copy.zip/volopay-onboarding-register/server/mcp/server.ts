import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { z } from 'zod';
import type { Request, Response } from 'express';
import { db } from '../db/db.js';
import { getWorkspace, listOnboardings, searchRecords, onboardingSummary, getCommitments, getTasks, getOverdue, getActivity, submitProposal } from '../services.js';
import type { Identity } from '../auth.js';

function identityFromRequest(req:Request):Identity {
 if(process.env.DEMO_AUTH==='false') throw new Error('Verified Supabase JWT authentication is not configured. MCP is disabled.');
 const raw=req.header('authorization')?.replace(/^Bearer\s+/i,'') ?? '';
 if(!raw.startsWith('demo:')) throw new Error('AUTH_REQUIRED');
 const userId=raw.slice(5);
 const row=db.prepare(`SELECT u.id userId,u.email,u.display_name displayName,m.workspace_id workspaceId,m.role FROM users u JOIN memberships m ON m.user_id=u.id AND m.status='active' WHERE u.id=? ORDER BY m.workspace_id LIMIT 1`).get(userId) as any;
 if(!row) throw new Error('AUTH_INVALID_TOKEN'); return row as Identity;
}
function buildServer(identity:Identity){
 const server=new McpServer({name:'volopay-onboarding-register',version:'1.0.0'});
 server.registerTool('list_onboardings',{description:'List onboarding projects in the authenticated workspace. Team Members see only onboardings they belong to.',inputSchema:{status:z.enum(['Active','At Risk','On Hold','Completed','Archived']).optional()}},async({status})=>({content:[{type:'text',text:JSON.stringify({data:listOnboardings(identity,status)})}]}));
 server.registerTool('get_onboarding_details',{description:'Get a safe overview of one onboarding. Does not include comments or unrestricted custom fields.',inputSchema:{onboarding_id:z.string().min(1)}},async({onboarding_id})=>{const data=onboardingSummary(identity,onboarding_id);return {content:[{type:'text',text:JSON.stringify({data})}],isError:!data};});
 server.registerTool('search_records',{description:'Search AI-approved task and commitment fields in the authenticated workspace.',inputSchema:{q:z.string().max(200).optional()}},async({q})=>({content:[{type:'text',text:JSON.stringify({data:searchRecords(identity,q??'')})}]}));
 server.registerTool('get_commitments',{description:'List commitments for an onboarding the authenticated user can access.',inputSchema:{onboarding_id:z.string().min(1)}},async({onboarding_id})=>{const data=getCommitments(identity,onboarding_id);return {content:[{type:'text',text:JSON.stringify({data})}],isError:!data};});
 server.registerTool('get_tasks',{description:'List tasks for an onboarding the authenticated user can access.',inputSchema:{onboarding_id:z.string().min(1)}},async({onboarding_id})=>{const data=getTasks(identity,onboarding_id);return {content:[{type:'text',text:JSON.stringify({data})}],isError:!data};});
 server.registerTool('get_overdue_items',{description:'List overdue open tasks and commitments. Overdue is calculated by the server.',inputSchema:{as_of:z.string().date().optional()}},async({as_of})=>({content:[{type:'text',text:JSON.stringify({data:getOverdue(identity,as_of)})}]}));
 server.registerTool('get_onboarding_summary',{description:'Return safe aggregate counts for an authorized onboarding.',inputSchema:{onboarding_id:z.string().min(1)}},async({onboarding_id})=>{const data=onboardingSummary(identity,onboarding_id);return {content:[{type:'text',text:JSON.stringify({data})}],isError:!data};});
 server.registerTool('get_activity_history',{description:'Return metadata-only activity history. Human comments and sensitive before/after values are excluded.',inputSchema:{}},async()=>({content:[{type:'text',text:JSON.stringify({data:getActivity(identity)})}]}));
 server.registerTool('submit_change_proposal',{description:'Submit a proposed event, commitment, task or decision change for human approval. This tool never changes operational records directly.',inputSchema:{target_onboarding_id:z.string().min(1),kind:z.enum(['event','commitment','task','decision']),operation:z.enum(['create','update']),base_record_version:z.number().int().positive().optional(),payload:z.record(z.string(),z.unknown()),idempotency_key:z.string().min(16).max(128)}},async(input)=>{try{const {idempotency_key,...body}=input;const proposal=submitProposal(identity,body,idempotency_key);return {content:[{type:'text',text:JSON.stringify({data:proposal})}]};}catch(e){return {content:[{type:'text',text:JSON.stringify({error:String((e as Error).message)})}],isError:true};}});
 return server;
}
export async function handleMcp(req:Request,res:Response){
 try {
  const identity=identityFromRequest(req); const server=buildServer(identity);
  const transport=new StreamableHTTPServerTransport({sessionIdGenerator:undefined,enableJsonResponse:true});
  res.on('close',()=>{void transport.close();void server.close();});
  await server.connect(transport);
  await transport.handleRequest(req,res,req.body);
 } catch(e) { const msg=(e as Error).message;res.status(msg==='AUTH_REQUIRED'||msg==='AUTH_INVALID_TOKEN'?401:503).json({error:{code:msg,message:msg==='AUTH_REQUIRED'?'A valid bearer token is required.':'MCP authentication is unavailable or invalid.'}}); }
}
