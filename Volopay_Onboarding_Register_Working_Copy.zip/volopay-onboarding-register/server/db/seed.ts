import { db } from './db.js';
import { randomUUID } from 'node:crypto';
const now = new Date().toISOString();
const seed = db.transaction(() => {
  const count = Number(db.prepare('SELECT COUNT(*) AS n FROM users').get()?.n ?? 0);
  if (count) return;
  const users = [
    ['user-admin','admin@demo.volopay.test','Aarav Mehta'],
    ['user-manager','manager@demo.volopay.test','Maya Iyer'],
    ['user-member','member@demo.volopay.test','Rohan Shah']
  ];
  const addUser = db.prepare('INSERT INTO users(id,email,display_name) VALUES(?,?,?)');
  users.forEach(u => addUser.run(...u));
  db.prepare('INSERT INTO workspaces(id,name,timezone) VALUES(?,?,?)').run('workspace-demo','Volopay Demo Workspace','Asia/Kolkata');
  const member = db.prepare('INSERT INTO memberships(workspace_id,user_id,role) VALUES(?,?,?)');
  member.run('workspace-demo','user-admin','Admin'); member.run('workspace-demo','user-manager','Implementation Manager'); member.run('workspace-demo','user-member','Team Member');
  const customer = db.prepare('INSERT INTO customers(id,workspace_id,display_name) VALUES(?,?,?)');
  customer.run('customer-northstar','workspace-demo','Northstar Demo Ltd'); customer.run('customer-bluepeak','workspace-demo','BluePeak Retail');
  const onboarding = db.prepare(`INSERT INTO onboardings(id,workspace_id,customer_id,name,status,owner_label,start_date,target_date,summary,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`);
  onboarding.run('onb-card-launch','workspace-demo','customer-northstar','Corporate card launch','Active','Implementation Manager','2026-10-01','2026-12-01','Coordinate card programme launch, integrations and employee rollout.',now,now);
  onboarding.run('onb-global-expense','workspace-demo','customer-bluepeak','Global expense rollout','At Risk','Implementation Manager','2026-09-15','2026-11-30','Complete policy mapping and finance sign-off before rollout.',now,now);
  const om = db.prepare('INSERT INTO onboarding_memberships(onboarding_id,user_id) VALUES(?,?)');
  for (const id of ['onb-card-launch','onb-global-expense']) { om.run(id,'user-admin'); om.run(id,'user-manager'); }
  om.run('onb-card-launch','user-member');
  const task = db.prepare(`INSERT INTO tasks(id,workspace_id,onboarding_id,title,status,priority,due_date,owner_role_label,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)`);
  task.run('task-mapping','workspace-demo','onb-card-launch','Validate employee data mapping','Open','High','2026-11-18','Implementation Manager',now,now);
  task.run('task-training','workspace-demo','onb-card-launch','Prepare administrator training','In Progress','Normal','2026-11-24','Team Member',now,now);
  task.run('task-policy','workspace-demo','onb-global-expense','Confirm expense policy mapping','Open','High','2026-11-10','Implementation Manager',now,now);
  const commitment = db.prepare(`INSERT INTO commitments(id,workspace_id,onboarding_id,title,status,due_date,owner_role_label,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)`);
  commitment.run('com-file','workspace-demo','onb-card-launch','Customer to provide employee file','Open','2026-11-17','Customer',now,now);
  commitment.run('com-signoff','workspace-demo','onb-global-expense','Finance to approve policy mapping','Open','2026-11-12','Customer',now,now);
  const event = db.prepare(`INSERT INTO events(id,workspace_id,onboarding_id,title,event_type,occurred_at,created_at) VALUES(?,?,?,?,?,?,?)`);
  event.run('event-kickoff','workspace-demo','onb-card-launch','Implementation kickoff completed','meeting','2026-10-02T09:00:00.000Z',now);
  const decision = db.prepare(`INSERT INTO decisions(id,workspace_id,onboarding_id,title,decision_status,decided_at,created_at) VALUES(?,?,?,?,?,?,?)`);
  decision.run('decision-rollout','workspace-demo','onb-card-launch','Pilot before full employee rollout','Confirmed','2026-10-15T10:00:00.000Z',now);
});
seed();
console.log('Demo database seeded.');
