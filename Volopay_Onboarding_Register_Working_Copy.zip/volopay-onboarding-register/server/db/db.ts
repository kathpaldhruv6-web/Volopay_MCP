import Database from 'better-sqlite3';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const path = resolve(process.env.DATABASE_PATH ?? './data/onboarding.sqlite');
mkdirSync(dirname(path), { recursive: true });
export const db = new Database(path);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS workspaces (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, timezone TEXT NOT NULL DEFAULT 'UTC'
);
CREATE TABLE IF NOT EXISTS memberships (
 workspace_id TEXT NOT NULL REFERENCES workspaces(id), user_id TEXT NOT NULL REFERENCES users(id),
 role TEXT NOT NULL CHECK(role IN ('Admin','Implementation Manager','Team Member')),
 status TEXT NOT NULL DEFAULT 'active', PRIMARY KEY(workspace_id,user_id)
);
CREATE TABLE IF NOT EXISTS customers (
 id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL REFERENCES workspaces(id), display_name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS onboardings (
 id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL REFERENCES workspaces(id), customer_id TEXT NOT NULL REFERENCES customers(id),
 name TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('Active','At Risk','On Hold','Completed','Archived')),
 owner_label TEXT NOT NULL, start_date TEXT, target_date TEXT, summary TEXT, version INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS onboarding_memberships (
 onboarding_id TEXT NOT NULL REFERENCES onboardings(id), user_id TEXT NOT NULL REFERENCES users(id),
 PRIMARY KEY(onboarding_id,user_id)
);
CREATE TABLE IF NOT EXISTS events (
 id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, onboarding_id TEXT NOT NULL REFERENCES onboardings(id),
 title TEXT NOT NULL, event_type TEXT NOT NULL, occurred_at TEXT NOT NULL, created_at TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS commitments (
 id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, onboarding_id TEXT NOT NULL REFERENCES onboardings(id),
 title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Open', due_date TEXT, owner_role_label TEXT,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS tasks (
 id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, onboarding_id TEXT NOT NULL REFERENCES onboardings(id),
 title TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Open', priority TEXT NOT NULL DEFAULT 'Normal', due_date TEXT,
 owner_role_label TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS decisions (
 id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, onboarding_id TEXT NOT NULL REFERENCES onboardings(id),
 title TEXT NOT NULL, decision_status TEXT NOT NULL, decided_at TEXT, created_at TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS comments (
 id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, onboarding_id TEXT NOT NULL REFERENCES onboardings(id),
 parent_type TEXT NOT NULL, parent_id TEXT NOT NULL, author_id TEXT NOT NULL REFERENCES users(id),
 body TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS proposals (
 id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, onboarding_id TEXT NOT NULL REFERENCES onboardings(id),
 proposer_id TEXT NOT NULL REFERENCES users(id), kind TEXT NOT NULL CHECK(kind IN ('event','commitment','task','decision')),
 operation TEXT NOT NULL CHECK(operation IN ('create','update')), payload TEXT NOT NULL, base_record_version INTEGER,
 status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','NEEDS_REVIEW','APPROVED','REJECTED','EXPIRED','INVALID','WITHDRAWN')),
 reason TEXT, idempotency_key TEXT NOT NULL, request_hash TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(workspace_id,proposer_id,idempotency_key)
);
CREATE TABLE IF NOT EXISTS audit_events (
 id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, actor_id TEXT NOT NULL, action TEXT NOT NULL,
 entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, metadata TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
 id TEXT PRIMARY KEY, workspace_id TEXT NOT NULL, user_id TEXT NOT NULL, title TEXT NOT NULL,
 body TEXT NOT NULL, read_at TEXT, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_onboardings_workspace_updated ON onboardings(workspace_id,updated_at DESC,id);
CREATE INDEX IF NOT EXISTS idx_tasks_workspace_due ON tasks(workspace_id,due_date,status);
CREATE INDEX IF NOT EXISTS idx_commitments_workspace_due ON commitments(workspace_id,due_date,status);
CREATE INDEX IF NOT EXISTS idx_proposals_workspace_status ON proposals(workspace_id,status,created_at DESC);
`);
