# Volopay Unified Onboarding Operations Register — local demonstration

This project is a standalone, synthetic-data demonstration of an onboarding operations register with a human approval workflow and a remote MCP interface. It is aligned to the supplied Shared Integration Contract's product boundary: Claude may read approved AI-safe fields and submit pending change proposals; only a human approver can commit a proposal. Human comments stay in the application and are not exposed as MCP tools.

## Important status and security boundary

**This is a local demo, not a production-ready deployment.** The local `DEMO_AUTH` mode uses a caller-controlled demo user header for the browser and `Bearer demo:<user-id>` for MCP. This is intentionally convenient for local evaluation and is not authentication. Never expose this mode to the public internet.

The shared contract specifies verified Supabase Auth JWT validation (JWKS, exact issuer, `aud=authenticated`, expiry) and forwarding of the signed end-user token to the backend. That production delegated-auth integration is not implemented here because it requires the actual Supabase project configuration and a verified integration design. When `DEMO_AUTH=false`, the current middleware deliberately fails closed rather than pretending to authenticate.

No production Supabase project, credentials, RLS migration, public hosting, or Claude account was accessed. No deployment is performed by this project.

## Requirements

- Node.js 22 or newer
- npm 10 or newer

## Run locally

```bash
cp .env.example .env
npm install
npm run db:seed
npm run dev
```

Open the Vite URL printed by Vite (normally `http://localhost:5173`). The API is `http://localhost:8789`; health check: `http://localhost:8789/health`.

Demo users (choose from the user selector):

- `admin@demo.volopay.test` — Admin
- `manager@demo.volopay.test` — Implementation Manager
- `member@demo.volopay.test` — Team Member, assigned to one onboarding only

These are synthetic demo identities, not passwords or production accounts.

## MCP

The stateless Streamable HTTP MCP endpoint is `http://localhost:8789/mcp` for local testing. Use bearer token `demo:user-admin` or `demo:user-manager` or `demo:user-member` in a local MCP test client. This token format is a demo-only identity selector and is not OAuth. Do not enter it into a public Claude connector.

Nine tools are registered: `list_onboardings`, `get_onboarding_details`, `search_records`, `get_commitments`, `get_tasks`, `get_overdue_items`, `get_onboarding_summary`, `get_activity_history`, and `submit_change_proposal`.

The MCP proposal tool supports typed event, commitment, task and decision proposals. It cannot approve, reject, or write operational rows. Approval/rejection happens in the human Approval Centre. Comments are human-only.

## Validation

```bash
npm run build
npm test
```

The build and test commands have not yet been run in this environment because dependency installation and native SQLite build availability have not been verified. Do not treat this README as a claim that those checks passed.

## Production work still required

1. Implement and verify Supabase Auth JWT validation against configured JWKS, issuer, audience and expiry.
2. Forward the delegated end-user token to the MCP backend; never use a service-role token as the user's identity.
3. Add production PostgreSQL migrations and tested RLS policies for every workspace-owned table.
4. Harden proposal transaction semantics: target version recheck, atomic operational write + approval history + audit, and durable idempotency under concurrent retries.
5. Complete all typed human APIs and authorization checks from the contract, including onboarding membership administration, task dependencies, decisions, external references, custom fields and notifications.
6. Complete field-level AI policy review. The demo currently exposes only a narrow allowlist and does not implement a full classification system for arbitrary free text.
7. Add pagination cursors, rate limiting, response-size limits, request IDs, and production-grade audit retention.
8. Run API/MCP conformance, security, concurrency, RLS and end-to-end tests.
9. Deploy only after the above are complete and the real Claude remote MCP connection is verified.

See `docs/ARCHITECTURE.md`, `docs/SECURITY.md`, `docs/CLAUDE_SETUP.md`, and `docs/DEPLOYMENT.md`.
