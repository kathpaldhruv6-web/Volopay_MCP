"""Static/schema smoke checks only; not API, auth, RLS or MCP integration tests."""
from pathlib import Path
import re, sqlite3
ROOT = Path(__file__).resolve().parents[1]
src = (ROOT / 'server/db/db.ts').read_text()
match = re.search(r'db\.exec\(`(.*?)`\);', src, re.S)
assert match, 'Database schema block missing'
conn = sqlite3.connect(':memory:')
conn.executescript(match.group(1))
tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
required = {'users','workspaces','memberships','customers','onboardings','onboarding_memberships','events','commitments','tasks','decisions','comments','proposals','audit_events','notifications'}
assert required <= tables, f'Missing tables: {required-tables}'
server = (ROOT/'server/mcp/server.ts').read_text()
tools = {'list_onboardings','get_onboarding_details','search_records','get_commitments','get_tasks','get_overdue_items','get_onboarding_summary','get_activity_history','submit_change_proposal'}
for tool in tools:
    assert f"registerTool('{tool}'" in server, f'Missing MCP tool: {tool}'
assert "registerTool('approve" not in server, 'MCP must not expose approval'
assert "registerTool('reject" not in server, 'MCP must not expose rejection'
assert 'add_comment' not in server, 'Human comments must remain outside MCP'
print(f'PASS: SQLite schema ({len(required)} required tables) and {len(tools)} MCP tool registrations.')
print('LIMITATION: static/schema smoke only; no TypeScript build, auth, RLS, HTTP or Claude integration was tested.')
