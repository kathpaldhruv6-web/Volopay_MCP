# Claude setup

This local demo is not publicly reachable and its `demo:<user-id>` bearer token is not a real OAuth credential. Therefore it must not be added as a public Claude connector.

After production delegated authentication and public HTTPS deployment are implemented:

1. Publish the approved Streamable HTTP MCP endpoint over HTTPS.
2. Verify MCP authorization discovery and end-user token forwarding against the current MCP authorization specification and Claude's connector behavior.
3. Add the connector in Claude's settings using the deployed MCP URL.
4. Sign in with an individual user account and authorize only the required workspace scopes.
5. Verify `list_onboardings` and `get_onboarding_summary`.
6. Ask Claude to propose a task or event. Confirm it appears as `PENDING` in the application's Approval Centre and has not changed the operational register.
7. Approve it as a different authorized Admin/Implementation Manager and confirm the same record appears in the register.

Do not claim Claude integration complete until the real hosted connector and delegated user identity have been tested.
