# Architecture

```mermaid
flowchart LR
  U[Human user] --> UI[React operations register]
  C[Claude using user's subscription] --> MCP[Remote MCP server]
  UI --> API[Application API]
  MCP --> API
  API --> AUTH[Identity and membership checks]
  AUTH --> SVC[Shared domain services]
  SVC --> DB[(SQLite demo database)]
  SVC --> AUD[Audit events]
  MCP -->|read| SAFE[AI-safe projection]
  MCP -->|write proposal only| P[Pending proposal]
  P --> UI
  UI -->|human approval| SVC
```

The UI and MCP operate on the same persisted records. MCP reads use a deliberately narrow projection. MCP writes create pending proposals only. A human Admin or Implementation Manager reviews and approves/rejects proposals in the application. Human comments are not exposed to MCP.

The local identity adapter is demo-only. Production requires the contract's verified Supabase end-user JWT and current membership checks on each request.
