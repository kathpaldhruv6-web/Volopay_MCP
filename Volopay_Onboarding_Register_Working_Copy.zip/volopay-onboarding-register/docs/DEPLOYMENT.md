# Deployment readiness

Deployment is intentionally not automated. Do not expose the local demo authentication mode publicly.

Before hosting, replace the demo identity adapter with verified Supabase Auth JWT validation, forward the signed end-user token, move persistence to PostgreSQL, implement and test RLS, complete typed API coverage, harden proposal approval/idempotency and audit transactions, add rate limiting and request IDs, and run security/conformance tests.

Configure `DEMO_AUTH=false` only after the production verifier is implemented. In this codebase it currently fails closed, which is safer than accepting demo identity on a public host.
