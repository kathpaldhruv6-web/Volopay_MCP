# Security notes

## Implemented in the local demo

- Workspace ID is derived from the selected demo identity, not accepted as an MCP authority claim.
- Team Members are restricted to onboardings in `onboarding_memberships` for the implemented read paths.
- MCP tool inputs do not accept user IDs, roles, or workspace membership claims.
- MCP writes create pending proposals only; the MCP tool has no approve/reject capability.
- Human comments are application-only and excluded from MCP.
- MCP output is intentionally narrow and omits comments and arbitrary custom fields.
- Operational changes from proposal approval are performed inside a database transaction in this local demo.

## Not production-safe / not yet implemented

- `x-demo-user-id` and `Bearer demo:<id>` are caller-controlled local demo identity, not authentication.
- Supabase JWT signature/JWKS/issuer/audience/expiry validation and delegated token forwarding are not implemented.
- SQLite demo schema has no PostgreSQL RLS. Do not deploy it as a multi-tenant production database.
- Proposal approval concurrency, idempotency replay, full version conflict resolution, audit immutability and transaction race testing are not complete.
- Rate limiting, CSRF protections for a real login flow, session management, hardened CORS, production secrets and operational monitoring are not implemented.
- Arbitrary free-text AI field classification is not solved by a generic regex. Unknown fields must remain blocked in production.

Production must fail closed until these controls are implemented and tested.
